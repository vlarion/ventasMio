from django.apps import AppConfig


class MantenedorConfig(AppConfig):
    name = 'mantenedor'
