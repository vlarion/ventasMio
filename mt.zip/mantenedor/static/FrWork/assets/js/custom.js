function nobackbutton(){
     /*
    window.location.hash="no-back-button";
    window.location.hash="Again-No-back-button" //chrome
    window.onhashchange= function(){window.location.hash="no-back-button";}
    */
    window.location.hash="Harrys";
    window.location.hash="Again-Harrys" //chrome
    window.onhashchange= function(){window.location.hash="Harrys";}
   
}